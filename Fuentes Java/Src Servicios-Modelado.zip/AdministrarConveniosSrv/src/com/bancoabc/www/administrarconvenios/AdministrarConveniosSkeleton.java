
/**
 * AdministrarConveniosSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.4  Built on : Dec 28, 2015 (10:03:39 GMT)
 */
    package com.bancoabc.www.administrarconvenios;

import bancoabc.www.entidadcomun.MensajeTransaccion;

/**
     *  AdministrarConveniosSkeleton java skeleton for the axisService
     */
    public class AdministrarConveniosSkeleton{
        
         
        /**
         * Auto generated method signature
         * 
                                     * @param crearConvenio 
             * @return crearConvenioResponse 
         */
        
                 public com.bancoabc.www.administrarconvenios.CrearConvenioResponse crearConvenio
                  (
                  com.bancoabc.www.administrarconvenios.CrearConvenio crearConvenio
                  )
            {
                	 com.bancoabc.www.administrarconvenios.CrearConvenioResponse response = new com.bancoabc.www.administrarconvenios.CrearConvenioResponse();
                	 MensajeTransaccion mensaje = new MensajeTransaccion();
                	 mensaje.setMensaje("Resultado exitoso");
                	 mensaje.setResult(true);
                	 response.setCrearConvenioResponse(mensaje);
                	 return response;
        }
                 
                 public EliminarConvenioResponse eliminarConvenio(){
                	 EliminarConvenioResponse response = new EliminarConvenioResponse();
                	 MensajeTransaccion mensaje = new MensajeTransaccion();
                	 mensaje.setMensaje("Resultado exitoso");
                	 mensaje.setResult(true);
                	 response.setEliminarConvenioResponse(mensaje);
                	 return response;
                 }
     
    }
    