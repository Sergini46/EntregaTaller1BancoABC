
/**
 * CompensaIISkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.4  Built on : Dec 28, 2015 (10:03:39 GMT)
 */
package com.bancoabc.www.compensaii;

import java.rmi.RemoteException;

import com.BancoABC.www.NotificarCompensacion.NotificarCompensacionProxy;

import bancoabc.www.entidadcomun.MensajeTransaccion;
import co.servicios.www.pagos.schemas.Pago;
import co.servicios.www.pagos.schemas.ReferenciaFactura;
import co.servicios.www.pagos.schemas.Resultado;
import co.servicios.www.pagos.service.PagosInerfaceProxy;

/**
 *  CompensaIISkeleton java skeleton for the axisService
 */
public class CompensaIISkeleton{


	/**
	 * Auto generated method signature
	 * 
	 * @param compensacion 
	 * @return compensacionResponse 
	 */

	public com.bancoabc.www.compensaii.CompensacionResponse compensacion
	(
			com.bancoabc.www.compensaii.Compensacion compensacion
			)
	{
		//if()tipo servicio es 3 llamar al de notificar sino llamar al de compensar
		com.bancoabc.www.compensaii.CompensacionResponse response = new com.bancoabc.www.compensaii.CompensacionResponse();
		MensajeTransaccion mensaje = new MensajeTransaccion();

		if( compensacion.getCompensacion().getTipoServicio().equals("3") ){
			NotificarCompensacionProxy proxy = new NotificarCompensacionProxy();
			javax.xml.rpc.holders.StringHolder h= new javax.xml.rpc.holders.StringHolder(" ");
			javax.xml.rpc.holders.BooleanHolder b = new javax.xml.rpc.holders.BooleanHolder(true);
			try {
				proxy.notificarTransaccion("", "", "", 12, h, b);
				mensaje.setResult(true);
				mensaje.setMensaje("Resultado Exitoso");
			} catch (RemoteException e) {
				e.printStackTrace();
				mensaje.setResult(false);
				mensaje.setMensaje("Error!!!");
			}
		}else{
			PagosInerfaceProxy proxy = new PagosInerfaceProxy();
			Pago requestCompensarExterno = new Pago();
			ReferenciaFactura referenciaFactura = new ReferenciaFactura();
			referenciaFactura.setReferenciaFactura(compensacion.getCompensacion().getNoFactura());
			requestCompensarExterno.setReferenciaFactura(referenciaFactura);
			try {
				Resultado resultado= proxy.compensar(requestCompensarExterno);
				System.out.println("Resultado compensacion:::"+resultado.getMensaje());
				mensaje.setResult(true);
				mensaje.setMensaje(resultado.getMensaje());
			} catch (RemoteException e) {
				e.printStackTrace();
			}
		}
		
		response.setCompensacionResponse(mensaje);
		return response;
	}

}
