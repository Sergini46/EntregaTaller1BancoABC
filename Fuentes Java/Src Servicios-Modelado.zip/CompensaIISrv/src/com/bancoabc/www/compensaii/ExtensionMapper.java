
/**
 * ExtensionMapper.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.4  Built on : Dec 28, 2015 (10:04:10 GMT)
 */

        
            package com.bancoabc.www.compensaii;
        
            /**
            *  ExtensionMapper class
            */
            @SuppressWarnings({"unchecked","unused"})
        
        public  class ExtensionMapper{

          public static java.lang.Object getTypeObject(java.lang.String namespaceURI,
                                                       java.lang.String typeName,
                                                       javax.xml.stream.XMLStreamReader reader) throws java.lang.Exception{

              
                  if (
                  "http://www.BancoABC/EntidadComun".equals(namespaceURI) &&
                  "MensajeTransaccion".equals(typeName)){
                   
                            return  bancoabc.www.entidadcomun.MensajeTransaccion.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://www.BancoABC/EntidadComun".equals(namespaceURI) &&
                  "Productos".equals(typeName)){
                   
                            return  bancoabc.www.entidadcomun.Productos.Factory.parse(reader);
                        

                  }

              
                  if (
                  "http://www.BancoABC/EntidadComun".equals(namespaceURI) &&
                  "MensajePago".equals(typeName)){
                   
                            return  bancoabc.www.entidadcomun.MensajePago.Factory.parse(reader);
                        

                  }

              
             throw new org.apache.axis2.databinding.ADBException("Unsupported type " + namespaceURI + " " + typeName);
          }

        }
    