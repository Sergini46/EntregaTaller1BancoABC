
/**
 * RealizarPagoSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.4  Built on : Dec 28, 2015 (10:03:39 GMT)
 */
package com.bancoabc.www.realizarpago;

import java.rmi.RemoteException;

import bancoabc.www.entidadcomun.MensajeTransaccion;
import co.servicios.www.pagos.schemas.Pago;
import co.servicios.www.pagos.schemas.ReferenciaFactura;
import co.servicios.www.pagos.schemas.Resultado;
import co.servicios.www.pagos.service.PagosInerfaceProxy;

/**
 *  RealizarPagoSkeleton java skeleton for the axisService
 */
public class RealizarPagoSkeleton{


	/**
	 * Auto generated method signature
	 * 
	 * @param realizarPago 
	 * @return realizarPagoResponse 
	 */

	public com.bancoabc.www.realizarpago.RealizarPagoResponse realizarPago
	(
			com.bancoabc.www.realizarpago.RealizarPago realizarPago
			)
	{
		com.bancoabc.www.realizarpago.RealizarPagoResponse response = new com.bancoabc.www.realizarpago.RealizarPagoResponse();
		MensajeTransaccion mensaje = new MensajeTransaccion();

		PagosInerfaceProxy proxy = new PagosInerfaceProxy();


		ReferenciaFactura referenciaFactura = new ReferenciaFactura();
		referenciaFactura.setReferenciaFactura("3333");

		Pago pagoRequest = new Pago();
		pagoRequest.setReferenciaFactura(referenciaFactura);
		pagoRequest.setTotalPagar(120000);

		try {
			Resultado pagoResponse=proxy.pagar(pagoRequest);
			System.out.println("Response servicio externo:::"+pagoResponse.getMensaje());
			mensaje.setMensaje(pagoResponse.getMensaje());
			mensaje.setResult(true);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		response.setRealizarPagoResponse(mensaje);
		return response;
	}

}
