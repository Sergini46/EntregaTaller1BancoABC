
/**
 * VerificarSaldoSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.4  Built on : Dec 28, 2015 (10:03:39 GMT)
 */
    package com.bancoabc.www.verificarsaldo;

import bancoabc.www.entidadcomun.MensajeTransaccion;

/**
     *  VerificarSaldoSkeleton java skeleton for the axisService
     */
    public class VerificarSaldoSkeleton{
        
         
        /**
         * Auto generated method signature
         * 
                                     * @param verificarSaldo 
             * @return verificarSaldoResponse 
         */
        
                 public com.bancoabc.www.verificarsaldo.VerificarSaldoResponse verificarSaldo
                  (
                  com.bancoabc.www.verificarsaldo.VerificarSaldo verificarSaldo
                  )
            {
                	 com.bancoabc.www.verificarsaldo.VerificarSaldoResponse response = new com.bancoabc.www.verificarsaldo.VerificarSaldoResponse();
                	 MensajeTransaccion mensaje = new MensajeTransaccion();
                	 mensaje.setMensaje("Resultado exitoso");
                	 mensaje.setResult(true);
                	 response.setVerificarSaldoResponse(mensaje);
                	 return response;
        }
     
    }
    