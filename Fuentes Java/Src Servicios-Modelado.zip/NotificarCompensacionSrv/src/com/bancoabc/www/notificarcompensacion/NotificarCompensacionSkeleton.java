
/**
 * NotificarCompensacionSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.4  Built on : Dec 28, 2015 (10:03:39 GMT)
 */
    package com.bancoabc.www.notificarcompensacion;

import bancoabc.www.entidadcomun.MensajeTransaccion;

/**
     *  NotificarCompensacionSkeleton java skeleton for the axisService
     */
    public class NotificarCompensacionSkeleton{
        
         
        /**
         * Auto generated method signature
         * 
                                     * @param notificarTransaccion 
             * @return notificarTransaccionResponse 
         */
        
                 public com.bancoabc.www.notificarcompensacion.NotificarTransaccionResponse notificarTransaccion
                  (
                  com.bancoabc.www.notificarcompensacion.NotificarTransaccion notificarTransaccion
                  )
            {	
                	 
                	 com.bancoabc.www.notificarcompensacion.NotificarTransaccionResponse respose=new com.bancoabc.www.notificarcompensacion.NotificarTransaccionResponse();
                	 MensajeTransaccion mensaje = new MensajeTransaccion();
                	 mensaje.setMensaje("Resultado exitoso");
                	 mensaje.setResult(true);
                	 respose.setNotificarTransaccionResponse(mensaje);
                	 
                	 return respose;
        }
     
    }
    