
/**
 * ConsultaSaldoSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.4  Built on : Dec 28, 2015 (10:03:39 GMT)
 */
    package com.bancoabc.www.consultasaldo;

import java.rmi.RemoteException;

import co.servicios.www.pagos.schemas.ReferenciaFactura;
import co.servicios.www.pagos.schemas.ResultadoConsulta;
import co.servicios.www.pagos.service.PagosInerfaceProxy;

/**
     *  ConsultaSaldoSkeleton java skeleton for the axisService
     */
    public class ConsultaSaldoSkeleton{
        
         
        /**
         * Auto generated method signature
         * 
                                     * @param consultaSaldoPagar 
             * @return consultaSaldoPagarResponse 
         */
        
                 public com.bancoabc.www.consultasaldo.ConsultaSaldoPagarResponse consultaSaldoPagar
                  (
                  com.bancoabc.www.consultasaldo.ConsultaSaldoPagar consultaSaldoPagar
                  )
            {	
                	ConsultaSaldoPagarResponse response = new ConsultaSaldoPagarResponse();
                	PagosInerfaceProxy proxy = new PagosInerfaceProxy();
             		ReferenciaFactura request = new ReferenciaFactura();
             		request.setReferenciaFactura("3333");
             		
             		
             		try {
             			ResultadoConsulta responseExterno=proxy.cosultar(request);
             			System.out.println("Total a pagar:::"+responseExterno.getTotalPagar());
             			com.bancoabc.www.consultasaldo.ConsultarSaldoPagarResponse obj = new com.bancoabc.www.consultasaldo.ConsultarSaldoPagarResponse();
             			obj.setReferenciaFactura(responseExterno.getReferenciaFactura().getReferenciaFactura());
             			obj.setTotalPagar(responseExterno.getTotalPagar());
             			response.setConsultaSaldoPagarResponse(obj);
             		} catch (RemoteException e) {
             			e.printStackTrace();
             		}	 
             		return response;
            }
     
    }
    