
/**
 * OpcionesPagoSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.6.4  Built on : Dec 28, 2015 (10:03:39 GMT)
 */
    package bancoabc.www.opcionespago;

import bancoabc.www.entidadcomun.MensajeTransaccion;
import bancoabc.www.entidadcomun.Productos;

/**
     *  OpcionesPagoSkeleton java skeleton for the axisService
     */
    public class OpcionesPagoSkeleton{
        
         
        /**
         * Auto generated method signature
         * 
                                     * @param opcionesDePago 
             * @return opcionesDePagoResponse 
         */
        
                 public bancoabc.www.opcionespago.OpcionesDePagoResponse opcionesDePago
                  (
                  bancoabc.www.opcionespago.OpcionesDePago opcionesDePago
                  )
            {
                	 OpcionesDePagoResponse response = new OpcionesDePagoResponse();
                	 bancoabc.www.opcionespago.OpcionesDePagoResponseSequence[] opcionesPago = new bancoabc.www.opcionespago.OpcionesDePagoResponseSequence[1];
                	 OpcionesDePagoResponseSequence sequence = new OpcionesDePagoResponseSequence();
                	 Productos productos = new Productos();
                	 String[] strProductos = {"Cuenta ahorros","Cuenta Corriente", "Tarjeta Debito", "Tarjeta Credito"};
                	 productos.setProducto(strProductos);
                	 sequence.setProductos(productos);
                	 opcionesPago[0] = sequence;
                	
                	 response.setOpcionesDePagoResponseSequence(opcionesPago);
                	 
                	 return response;
        }
     
    }
    